Algoritmo Cafeteria
	Definir tazasManana, tazasTarde Como Entero
    Definir inventarioInicial, kilosConsumidos Como Real
    Definir precioTaza, ingresoTotal Como Real
    Definir totalGalletas, clientes, galletasSobrantes Como Entero
    Definir ladoTerraza, areaTerraza Como Real
	//Valores de prueba//
	tazasManana <- 45
    tazasTarde <- 60
    inventarioInicial <- 15.5
    kilosConsumidos <- 3.2
    precioTaza <- 2000
    totalGalletas <- 135
    clientes <- 20
    ladoTerraza <- 4.5
	Escribir "SISTEMA DE CAJA E INVENTARIO DE LA CAFETER�A"
	totalTazas <- tazasManana + tazasTarde                        //SUMA//
	Escribir "Total de Tazas vendidas hoy " totalTazas
	inventarioFinal <- inventarioInicial - kilosConsumidos              //resta//
	Escribir "Granos de cafe en el inventario " inventarioFinal " Kilos"
	ingresoTotal <- totalTazas * precioTaza                              //Multiplicacion//
	Escribir "Ingreso Total del dia " ingresoTotal " Pesos"
	galletasPorcliente <- trunc (totalGalletas / clientes)                                //division//
	Escribir "Galletas obsequiadas a cada cliente " galletasPorcliente
	galletasSobrantes <- totalGalletas MOD clientes                          // residuo//
	Escribir "Galletas sobrantes " galletasSobrantes
	Escribir "AREA A REMODELAR DE LA CAFETERIA"
	areaTerraza <- ladoTerraza ^ 2                                               //Potencia//
	Escribir "El area a remodelar es " areaTerraza " M�2 Aproximadamente" 
FinAlgoritmo
