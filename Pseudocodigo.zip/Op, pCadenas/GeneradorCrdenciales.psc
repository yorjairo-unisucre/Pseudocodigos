Algoritmo Generador_credenciales
	Definir nombre, apellido, YearText, fragmento1, fragmento2 Como Caracter
	Definir nacimiento Como Entero
	Escribir "ingrese su primer nombre (Tres Caracteres como minimo)"
	Leer nombre
	Escribir "ingrese su primer apellido (Tres Caracteres como minimo"
	Leer apellido
	Si Longitud(nombre) >= 3 Y LOngitud(apellido) >= 3 Entonces
		nombre = Minusculas(nombre)
		Apellido = Minusculas(apellido)
		nacimiento <- ConvertirANumero(YearText)
		sino 
		Escribir "Su nombre o apellido no es valido"
	FinSi
	Si Longitud(nombre) >= 3 Y Longitud(apellido) >= 3 Entonces
		Escribir "Ingrese su a�o de nacimiento"
		Leer YearText
		nacimiento <- ConvertirANumero(YearText)
		Si 2026 - nacimiento <= 100 Y nacimiento <= 2008 entonces  
			fragmento1 = SubCadena(nombre,1,3)
			fragmento2 = SubCadena(apellido,1,3)
			Id_estudiante <- Concatenar(fragmento1,fragmento2)
			Edad <- 2026 - nacimiento
			Id_estudiante_final <- Concatenar(Id_estudiante, ConvertirATexto(edad))
			Id_estudiante_final = Mayusculas(Id_estudiante_final)
			
			correo <- Concatenar(nombre,".")
			correo = Concatenar(correo,apellido)
			correo = Concatenar(correo,"@estudiantesunisucre.com")
			Escribir "--- REGISTRO EXITOSO ---"
			Escribir "Edad calculada " edad " A�os"
			Escribir "ID estudiantil: " id_estudiante_final
			Escribir "Correo estudiantil asignado " correo 
			Escribir " --- BIENVENID@ A LA COMUNIDAD UNISUCRE�A --- "
		SiNo
			Escribir "El a�o ingresado no es valido"
			FinSi
		FinSi
		
		
		
FinAlgoritmo

