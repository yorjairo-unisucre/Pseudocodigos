Algoritmo CajaRapidaSupermercadoAvanzada
    Definir metodoPago, estadoProducto Como Caracter
    Definir cantidadArticulos, edadCliente, hora, horaCierre Como Entero
    Definir montoEntregado, totalCompra Como Real
    horaCierre <- 22
    Escribir "Ingrese la hora actual (formato 24h):"
    Leer hora
    Si hora < horaCierre Entonces
        Escribir "La tienda esta abierta. Iniciando sistema de caja."
        Repetir
            Escribir "Ingrese el estado del producto (Nuevo o Roto):"
            Leer estadoProducto
            estadoProducto <- Minusculas(estadoProducto)
        Hasta Que estadoProducto = "nuevo" O estadoProducto = "roto"
        Si estadoProducto <> "roto" Entonces
            Escribir "Ingrese la cantidad de articulos:"
            Leer cantidadArticulos
            Si cantidadArticulos <= 10 Entonces
                Escribir "Acceso permitido a caja rapida."
                Escribir "Ingrese la edad del cliente:"
                Leer edadCliente
                Si edadCliente >= 18 Entonces
                    Escribir "Verificacion de edad aprobada."
                SiNo
                    Escribir "Advertencia: Venta de alcohol restringida."
                FinSi
                Escribir "Ingrese el total de la compra:"
                Leer totalCompra
                Repetir
                    Escribir "Ingrese el metodo de pago (Tarjeta o Efectivo):"
                    Leer metodoPago
                    metodoPago <- Minusculas(metodoPago)
                Hasta Que metodoPago = "tarjeta" O metodoPago = "efectivo"
                Si metodoPago = "efectivo" Entonces
                    Escribir "Ingrese el monto entregado por el cliente:"
                    Leer montoEntregado
                    Si montoEntregado > totalCompra Entonces
                        Escribir "Transaccion aprobada. Entregar cambio: ", montoEntregado - totalCompra
                    SiNo
                        Escribir "Transaccion aprobada. Cobro exacto."
                    FinSi
                SiNo
                    Escribir "Procesando pago con tarjeta. Transaccion aprobada."
                FinSi
            SiNo
                Escribir "Excede el limite de 10 articulos. Por favor, dirijase a las cajas regulares."
            FinSi
        SiNo
            Escribir "Operacion cancelada. No se puede procesar la venta de un producto roto."
        FinSi
    SiNo
        Escribir "La tienda ha cerrado. Sistema bloqueado."
    FinSi
FinAlgoritmo
 