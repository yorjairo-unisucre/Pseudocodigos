Algoritmo CalcularA�oBisiesto
	Definir Year Como Entero
	Escribir "ingrese el a�o a calcular"
	Leer Year
	Si (Year MOD 4 = 0) Y (Year MOD 100 <> 0) Entonces
		Escribir "El a�o " Year " es bisiesto"
	SiNo
		Escribir "El a�o " Year " no es biciesto"
	FinSi
FinAlgoritmo
