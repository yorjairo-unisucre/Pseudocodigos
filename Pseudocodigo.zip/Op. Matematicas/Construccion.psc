Algoritmo Construccion
	Definir base, altura, pesoCaja, desnivel Como Real
	
	Escribir "--- DATOS DEL PLANO ---"
	Escribir "Ingrese la medida de la base de la rampa (En metro)"
	Leer base
	Escribir "Ingrese la medida de la altura de la rampa (En metros)"
	leer altura
	Escribir "Ingrese el peso de la caja a subir (En kilos)"
	leer pesoCaja
	
	//uso de raiz para averiguar la longitud de la rampa aplicando la formula H = raiz a�2 + b�2
	LargeRampa <- raiz(base^2) + raiz(altura^2)
	
	//Uso de la Arcotangente para el �ngulo y despues pasar a grados segun la formula 1 rad � 180/pi //
	AnguloRad <- atan(base / altura)
	AnguloGrados <- AnguloRad * (180 / PI)
	
	//para saber cu�nta fuerza se necesita para empujar una caja por una rampa
	//multiplicas el peso de la caja por el Seno del �ngulo de inclinaci�n de la rampa.//
	
	fuerzaSubir <- sen(AnguloRad) * pesoCaja
	
	// USo del Valor Absoluto para calcular la diferencia entre la base y la altura sin importar el orden//
	desnivel <- abs(base - altura)
	
	Escribir "---CALCULOS EXACTOS ---"
	Escribir "La longitud de la rampa es de " trunc(LargeRampa) " Metros"
	EScribir "El angulo de la rampa es de " redon(AnguloGrados) " Metros"
	Escribir "La fuerza necesaria para subir la caja por la rampa es " redon(fuerzaSubir) " kg de empuje"
	Escribir "El desnivel entre la base y la altura es de " desnivel " Metros"
	
	//Compra en ferreteria//
	Escribir "--- LISTA PARA LA FERRETER�A ---"
	Escribir "Material a Comprar:  " redon(LargeRampa) " Metros"
	
	//Reporte
	Escribir "La medida de la rampa es " LargeRampa " Metros " "y presenta una inclinacion aproximada de " trunc(AnguloGrados) " Grados"
	
	
	
	
	
FinAlgoritmo
