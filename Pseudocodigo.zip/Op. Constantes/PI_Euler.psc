Algoritmo Laboratorio
	Definir tiempo, poblacionInicialBacteriana, poblacionFinal, radio Como Real
	
	// uso del numero pi para calcular en geometria//
	
	Escribir "--- Calculo de Area --- "
	Escribir "Ingrese el radio (En centimetros)"
	Leer radio
	area <- PI * (radio^2)
	Escribir "El area es " area 
	
	//uso de euler para estimar el crecimiento poblacional
	
	Escribir "--- Estimar Crecimiento Poblacional Bacteriano --- "
	Escribir "ingrese la cantidad inicial de bacterias"
	Leer poblacionInicialBacteriana
	Escribir "ingrese el tiempo estimado del esperimento"
	Leer tiempo
	poblacionFinal =  poblacionInicialBacteriana * (Euler^tiempo)
	Escribir "La poblacion final aproximada es " poblacionFinal
	
FinAlgoritmo
