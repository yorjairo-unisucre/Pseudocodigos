Algoritmo Prueba_Gratuita
	Definir yaregistrado Como Caracter
	Escribir "Ya tienes una cuenta registrada con nosotros (s/n)"
	Leer yaregistrado
	SI NO Minusculas(yaregistrado) == "s" Entonces
		Escribir "�Felicidades! Registrate para disfrutar de un periodo de 30 dias gratis"
	SiNo
		Escribir "Parece que ya eres mienbro, inicia sesion para acceder a tu cuenta"
	
	FinSi
	
FinAlgoritmo
