Algoritmo Monta�a_Rusa_Conjuncion
	Definir edad Como Entero
	Definir altura Como Real
	Escribir "Bienvenidos a la monta�a rusa mas extrema. "
	Escribir  "Tenga encuenta que para ingresar debe tener al menos 18 a�os de edad y medir mas de 1.50 metros"
	Escribir "Por favor digite su edad"
	Leer edad
	Escribir "Por favor digite su altura en metros"
	Leer altura 
	Si edad >= 18 Y altura > 1.50 Entonces
		Escribir "Puede ingresar"
	SiNo
		Escribir "No puede ingresar"
	FinSi
FinAlgoritmo
