Algoritmo Descuento_Cine_Disyuncion
	Definir edad Como Entero
	Definir estudiante Como Caracter
	Escribir "Bienvenidos a la taquilla del cine"
	Escribir "Por favor ingresa tu edad"
	Leer edad
	Escribir "Eres estudiante (S/N)"
	Leer estudiante
	Si edad >= 60 O Minusculas(estudiante) == "s"  Entonces
		Escribir "�Felicidades! Tienes derecho a un boleto con un descuento especial"
	SiNo
		Escribir "No aplicas para el descuento. El cobro sera a precio regular"
	FinSi
FinAlgoritmo
