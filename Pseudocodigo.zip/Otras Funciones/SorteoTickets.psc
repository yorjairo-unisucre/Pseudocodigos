Algoritmo SorteoDeTickets
    Definir nombreUsuario Como Caracter
    Definir asientoVIP, codigoSeguridad Como Entero
    Definir fechaTicket, horaTicket Como Entero
	
    Escribir "--- SISTEMA DE TICKETS VIP ---"
    Escribir "Ingrese su nombre para el registro:"
    Leer nombreUsuario
    fechaTicket = FechaActual()
    horaTicket = HoraActual()
    asientoVIP = Aleatorio(1, 50)
    codigoSeguridad = Azar(10000)
    
    Escribir "--- TICKET GENERADO CON �XITO ---"
    Escribir "Titular: ", nombreUsuario
    Escribir "Fecha de emisi�n (AAAAMMDD): ", fechaTicket
    Escribir "Hora de emisi�n (HHMMSS): ", horaTicket
    Escribir "Tu asiento asignado al azar es el n�mero: ", asientoVIP
    Escribir "C�digo de seguridad de tu ticket: ", codigoSeguridad
    Escribir "�Guarda este c�digo para ingresar al evento!"
FinAlgoritmo